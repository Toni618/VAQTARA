import React from 'react';
import { View, Text, Pressable, StyleSheet } from 'react-native';
import { useTranslation } from 'react-i18next';
import i18n from '../src/i18n';

export default function LanguageSelectScreen() {
  const { t } = useTranslation();
  const setLang = (lng: 'fa' | 'en') => i18n.changeLanguage(lng);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>RAVENDORA</Text>
      <Text style={styles.subtitle}>{t('selectLanguage')}</Text>
      <Pressable style={styles.button} onPress={() => setLang('fa')}>
        <Text style={styles.buttonText}>فارسی</Text>
      </Pressable>
      <Pressable style={styles.button} onPress={() => setLang('en')}>
        <Text style={styles.buttonText}>English</Text>
      </Pressable>
      <Text style={styles.note}>{t('scaffoldNote')}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#05060d', alignItems: 'center', justifyContent: 'center', padding: 24 },
  title: { color: '#e8ecff', fontSize: 34, fontWeight: '700', marginBottom: 12 },
  subtitle: { color: '#b9c2ff', fontSize: 18, marginBottom: 24 },
  button: { backgroundColor: '#141b3a', borderColor: '#2a3566', borderWidth: 1, paddingVertical: 14, paddingHorizontal: 28, borderRadius: 14, marginVertical: 8, minWidth: 220, alignItems: 'center' },
  buttonText: { color: '#fff', fontSize: 18 },
  note: { color: '#7f89b8', marginTop: 28, textAlign: 'center' },
});
